# EMMA – Tamil Voice Assistant (Web Version) 🎙️

Browser-based version of EMMA. Speak or type in **Tamil** or **English**; EMMA replies in text and voice.
No installation and no backend: it is a simple static website with an `assets` folder.

## Features
- 🎤 Voice input (Web Speech API, `ta-IN` / `en-IN`)
- 🔊 Spoken replies (browser text-to-speech)
- Time, date (Tamil weekday/month names), jokes, weather, YouTube, Google search, Wikipedia summary
- Tamil / English switch, quick-command chips, light and dark mode

## Run locally
Open `index.html` in **Chrome or Edge** (voice input works best there).
If the mic is blocked on a local file, run `python -m http.server` in this folder and open http://localhost:8000.

## Host on GitHub Pages (free link)
1. Create a new GitHub repository, e.g. `emma-web`.
2. Upload `index.html` and `README.md`.
3. Go to **Settings → Pages → Branch: main → / (root) → Save**.
4. Your site will be live at `https://<your-username>.github.io/emma-web/`.

## Notes
- Needs internet for speech recognition and Wikipedia.
- Tamil voice replies depend on the Tamil voice installed on your device; otherwise text is still shown.
- Firefox does not support voice input; typing still works.

## Author
Elamughil S S – B.Tech AI & Data Science, VSB College of Engineering Technical Campus

## License
MIT
